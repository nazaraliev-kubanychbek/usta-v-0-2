import React from 'react';
import Card from './Card'

const CardList = () => {
    return (
        <div>
            <Card />
        </div>
    );
}

export default CardList;
